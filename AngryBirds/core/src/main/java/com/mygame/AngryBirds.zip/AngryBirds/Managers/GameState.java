package com.mygame.AngryBirds.Managers;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;
import com.mygame.AngryBirds.Objects.*;
import com.mygame.AngryBirds.Screen.GameScreen;
import com.mygame.AngryBirds.Screen.HUD;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class GameState implements Serializable {
    private static final long serialVersionUID = 1L;

    // Detailed game state capture
    public int score;
    public int level;
    public List<BirdState> birdStates;
    public List<PigState> pigStates;
    public List<StructureState> structureStates;
    public float worldGravity;
    public Vector2 catapultPosition;
    public GroundState groundState;

    // Nested state classes
    public static class BirdState implements Serializable {
        public float x, y;
        public String birdType;
        public boolean wasFired;
        public float velocityX, velocityY;
    }

    public static class PigState implements Serializable {
        public float x, y;
        public float health;
        public String pigType;
    }

    public static class StructureState implements Serializable {
        public float x, y;
        public String structureType;
        public String textureName;
    }
    public static class GroundState implements Serializable {
        public float sx, ex, y;
        public float scale;
    }

    // Capture method for current game state
    public static GameState captureCurrentState(GameScreen gameScreen) {
        GameState state = new GameState();
        state.score = HUD.getScore();
        state.level = gameScreen.getCurrentLevel();
        state.worldGravity = gameScreen.world.getGravity().y;
        state.catapultPosition = gameScreen.getCatapultPosition();
        state.groundState = captureGroundState(gameScreen.ground);

        // Capture bird states
        state.birdStates = gameScreen.birds.stream()
                .map(GameState::captureBirdState)
                .collect(Collectors.toList());

        // Capture pig states
        state.pigStates = gameScreen.pigs.stream()
                .map(GameState::capturePigState)
                .collect(Collectors.toList());

        // Capture structure states
        state.structureStates = gameScreen.structures.stream()
                .map(GameState::captureStructureState)
                .collect(Collectors.toList());

        return state;
    }

    // Helper methods to capture individual object states
    private static BirdState captureBirdState(Bird bird) {
        BirdState state = new BirdState();
        state.x = bird.getInitialPosition().x;
        state.y = bird.getInitialPosition().y;
        state.birdType = bird.getClass().getSimpleName();
        state.wasFired = bird.wasFired;
        state.velocityX = bird.getBody().getLinearVelocity().x;
        state.velocityY = bird.getBody().getLinearVelocity().y;
        return state;
    }

    private static PigState capturePigState(Pig pig) {
        PigState state = new PigState();
        state.x = pig.getPostitionX();
        state.y = pig.getPostitionY();
        state.health = pig.returnHealth();
        state.pigType = pig.getClass().getSimpleName();
        return state;
    }

    private static StructureState captureStructureState(Structure structure) {
        StructureState state = new StructureState();
        state.x = structure.getPostitionX();
        state.y = structure.getPostitionY();
        state.structureType = structure.getClass().getSimpleName();
        state.textureName = structure.getTextureName();
        return state;
    }
    private static GroundState captureGroundState(Ground ground) {
        GroundState state = new GroundState();
        state.sx = ground.getPositionSX();
        state.ex = ground.getPositionEX();
        state.y = ground.getPositionY();
        state.scale = 100f;
        return state;
    }

    // Restoration method
    public void restoreGameState(GameScreen gameScreen) {
        try {
            // Remove all existing actors
            for (Actor actor : new Array.ArrayIterator<>(gameScreen.stage.getActors())) {
                if (actor instanceof Bird || actor instanceof Pig || actor instanceof Structure) {
                    gameScreen.stage.getActors().removeValue(actor, true);
                }
            }

            // Clear existing collections
            gameScreen.birds.clear();
            gameScreen.pigs.clear();
            gameScreen.structures.clear();

            // Safely recreate world
            if (gameScreen.world != null) {
                gameScreen.world.dispose();
            }
            gameScreen.world = new World(new Vector2(0, this.worldGravity), true);

            // Restore score and level
            HUD.setScore(this.score);

            if (this.groundState != null) {
                gameScreen.ground = new Ground(
                        gameScreen.world,
                        this.groundState.sx,
                        this.groundState.ex,
                        this.groundState.y
                );
                //gameScreen.stage.addActor(gameScreen.ground);
            }

            // Recreate game objects with null checks
            if (this.birdStates != null) {
                for (BirdState birdState : this.birdStates) {
                    Bird bird = createBirdFromState(gameScreen.world, birdState);
                    if (bird != null) {
                        gameScreen.birds.add(bird);
                        gameScreen.stage.addActor(bird);
                    }
                }
            }

            // Similar null checks for pigs and structures
            if (this.pigStates != null) {
                for (PigState pigState : this.pigStates) {
                    Pig pig = createPigFromState(gameScreen.world, pigState);
                    if (pig != null) {
                        gameScreen.pigs.add(pig);
                        gameScreen.stage.addActor(pig);
                    }
                }
            }

            if (this.structureStates != null) {
                for (StructureState structureState : this.structureStates) {
                    Structure structure = createStructureFromState(gameScreen.world, structureState);
                    if (structure != null) {
                        gameScreen.structures.add(structure);
                        gameScreen.stage.addActor(structure);
                    }
                }
            }

            // Reinitialize game components
            gameScreen.reinitializeGameComponents();

        } catch (Exception e) {
            System.err.println("Error restoring game state: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Factory methods for object recreation (placeholder implementations)
    private Bird createBirdFromState(World world, BirdState state) {
        Bird bird = null;
        switch (state.birdType) {
            case "RedBird":
                bird = new RedBird(world, state.x, state.y);
                break;
            // Add other bird types
            case "YellowBird":
                bird = new YellowBird(world,state.x,state.y);
                break;
            case "BlackBird":
                bird = new BlackBird(world, state.x, state.y);
                break;
        }
        if (bird != null) {
            bird.wasFired = state.wasFired;
            bird.getBody().setLinearVelocity(state.velocityX, state.velocityY);
        }
        return bird;
    }

    // Similar methods for createPigFromState and createStructureFromState
    private Pig createPigFromState(World world, PigState state){
        Pig pig = null;
        switch (state.pigType){
            case "BigPig":
                pig = new BigPig(world, state.x,state.y);
                break;
            case "CorporalPig":
                pig = new CorporalPig(world, state.x,state.y);
                break;
            case "CrownPig":
                pig = new CrownPig(world,state.x,state.y);
                break;
        }
        if (pig!=null){
            pig.setHealth(state.health);
        }
        return pig;
    }
    private Structure createStructureFromState(World world, StructureState state){
        Structure structure = null;
        switch (state.structureType){
            case "WoodStructure":
                structure = new WoodStructure(state.x, state.y, state.textureName, world);
                break;
            case "GlassStructure":
                structure = new GlassStructure(state.x, state.y, state.textureName, world);
                break;
            case "StoneStructure":
                structure = new StoneStructure(state.x, state.y, state.textureName, world);
                break;
        }
        return structure;
    }
}